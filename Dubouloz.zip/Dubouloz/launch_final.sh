service.mongod.start

mkdir data_json
wget -O ./data_json/tennis.json https://www.nycgovparks.org/bigapps/DPR_Tennis_001.json
wget -O ./data_json/basket.json https://www.nycgovparks.org/bigapps/DPR_Basketball_001.json

mkdir data_csv
wget -O ./data_csv/airquality.csv https://data.cityofnewyork.us/api/views/c3uy-2p5r/rows.csv?accessType=DOWNLOAD
wget -O ./data_csv/plaintes.csv https://data.cityofnewyork.us/api/views/5uac-w243/rows.csv?accessType=DOWNLOAD



python3 traitement_json.py



mongoimport --db ny --collection airquality --drop --type csv --headerline --file ./data_csv/airquality.csv
mongoimport --db ny --collection plaintes --drop --type csv --headerline --file ./data_csv/plaintes.csv
mongoimport --db ny --collection tennis --drop --file ./data_json/tennis.json
mongoimport --db ny --collection basket --drop --file ./data_json/basket.json



firefox https://www.nycgovparks.org/parks/walker-park/map




